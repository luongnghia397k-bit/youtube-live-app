import React, { useState } from 'react';
import {
  Smartphone,
  Code2,
  Terminal,
  HelpCircle,
  Radio,
  Github,
  Play,
  Repeat,
  Download,
  ExternalLink,
  Layers,
  Sparkles
} from 'lucide-react';
import { AndroidPhoneFrame } from './components/AndroidPhoneFrame';
import { AndroidAppUI } from './components/AndroidAppUI';
import { CodeInspector } from './components/CodeInspector';
import { FFmpegCommandBuilder } from './components/FFmpegCommandBuilder';
import { YouTubeGuideModal } from './components/YouTubeGuideModal';
import { StreamConfig } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'ffmpeg'>('simulator');
  const [isGuideOpen, setIsGuideOpen] = useState(false);

  // Default stream config state for command builder
  const [config, setConfig] = useState<StreamConfig>({
    rtmpUrl: 'rtmp://a.rtmp.youtube.com/live2',
    streamKey: '',
    loopVideo: true,
    videoSourceType: 'sample',
    selectedSampleId: 'nature_loop',
    qualityPreset: 'passthrough',
    customResolution: '1080p',
    bitrateKbps: 4500,
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-red-900 selection:text-red-100">
      {/* Top Header Navbar */}
      <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Branding */}
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-red-600 to-rose-500 text-white shadow-lg shadow-red-600/30">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  YouTube Live RTMP Streamer
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/10 text-red-400 border border-red-500/20">
                  Android Kotlin & FFmpeg
                </span>
              </div>
              <p className="text-xs text-slate-400">Stream local MP4 video files continuously to YouTube Live</p>
            </div>
          </div>

          {/* Navigation Tab Bar */}
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-900 border border-slate-800">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'simulator'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>Android App</span>
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'code'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>Kotlin Project</span>
            </button>

            <button
              onClick={() => setActiveTab('ffmpeg')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'ffmpeg'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Terminal className="w-4 h-4" />
              <span>FFmpeg Command</span>
            </button>
          </div>

          {/* Action Helper */}
          <button
            onClick={() => setIsGuideOpen(true)}
            className="hidden lg:inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-semibold transition-colors"
          >
            <HelpCircle className="w-4 h-4 text-red-400" />
            <span>YouTube Live Setup</span>
          </button>
        </div>
      </header>

      {/* Main App Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Requirement Checklist Summary Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20">
              <Play className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-200">1. Gallery Video Picker</div>
              <div className="text-[10px] text-slate-400">Select local MP4 from storage</div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-200">2. RTMP URL & Key</div>
              <div className="text-[10px] text-slate-400">YouTube server inputs</div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Repeat className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-200">3. Loop Video Toggle</div>
              <div className="text-[10px] text-slate-400">-stream_loop -1 repeat</div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-200">4. Start/Stop & FFmpeg</div>
              <div className="text-[10px] text-slate-400">FFmpegKit for Android</div>
            </div>
          </div>
        </div>

        {/* Tab Viewport */}
        {activeTab === 'simulator' && (
          <div className="py-2">
            <AndroidPhoneFrame>
              <AndroidAppUI onOpenGuide={() => setIsGuideOpen(true)} />
            </AndroidPhoneFrame>
          </div>
        )}

        {activeTab === 'code' && (
          <div className="py-2">
            <CodeInspector />
          </div>
        )}

        {activeTab === 'ffmpeg' && (
          <div className="py-2 space-y-6">
            <FFmpegCommandBuilder config={config} />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 py-6 px-4 text-center text-xs text-slate-500 bg-slate-950">
        <p>Built with React, Express, Jetpack Compose, Kotlin, and FFmpegKit for Android.</p>
      </footer>

      {/* YouTube Setup Modal */}
      <YouTubeGuideModal isOpen={isGuideOpen} onClose={() => setIsGuideOpen(false)} />
    </div>
  );
}
