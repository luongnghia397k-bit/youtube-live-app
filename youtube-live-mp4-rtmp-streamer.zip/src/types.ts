export type StreamStatus = 'OFFLINE' | 'CONNECTING' | 'LIVE' | 'STOPPING' | 'ERROR';

export type QualityPreset = '1080p60' | '720p30' | 'passthrough';

export interface StreamConfig {
  rtmpUrl: string;
  streamKey: string;
  loopVideo: boolean;
  videoSourceType: 'sample' | 'upload';
  selectedSampleId: string;
  uploadedFileName?: string;
  uploadedFileUrl?: string;
  uploadedFileSizeMb?: number;
  qualityPreset: QualityPreset;
  customResolution: string;
  bitrateKbps: number;
}

export interface StreamStats {
  status: StreamStatus;
  uptimeSeconds: number;
  bitrateKbps: number;
  fps: number;
  totalFrames: number;
  speedMultiplier: number;
  timePositionStr: string;
  errorMessage?: string;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success' | 'ffmpeg';
  message: string;
}

export interface SampleVideo {
  id: string;
  name: string;
  description: string;
  durationSeconds: number;
  resolution: string;
  sizeMb: number;
  thumbnailUrl: string;
  videoUrl: string;
}

export interface AndroidCodeFile {
  id: string;
  path: string;
  filename: string;
  language: 'kotlin' | 'xml' | 'groovy' | 'markdown';
  category: 'ui' | 'service' | 'manifest' | 'gradle' | 'docs';
  description: string;
  content: string;
}
