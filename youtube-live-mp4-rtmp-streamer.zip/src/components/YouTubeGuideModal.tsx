import React from 'react';
import { X, ExternalLink, CheckCircle2, AlertTriangle, Key, Radio, ShieldCheck, Copy } from 'lucide-react';

interface YouTubeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyPresetKey?: (key: string) => void;
}

export const YouTubeGuideModal: React.FC<YouTubeGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-red-500/10 text-red-500 border border-red-500/20">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">YouTube Live RTMP Setup Guide</h3>
              <p className="text-xs text-slate-400">Get your Stream Key and start live streaming MP4 videos</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 text-sm max-h-[80vh] overflow-y-auto">
          {/* Step 1 */}
          <div className="flex gap-4 p-4 rounded-xl bg-slate-800/50 border border-slate-700/50">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-red-600 font-bold text-white shrink-0">
              1
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-white flex items-center gap-2">
                Open YouTube Creator Studio
                <a
                  href="https://studio.youtube.com"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center text-xs text-red-400 hover:underline gap-1"
                >
                  studio.youtube.com <ExternalLink className="w-3 h-3" />
                </a>
              </h4>
              <p className="text-slate-300">
                Log into YouTube, click the <strong className="text-white">Create</strong> button (top right), and select{' '}
                <strong className="text-red-400">Go Live</strong>.
              </p>
              <div className="text-xs text-slate-400 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                ⚠️ <strong className="text-amber-400">First time live streaming?</strong> YouTube requires a one-time account phone verification. It takes up to 24 hours for YouTube to activate live streaming privileges.
              </div>
            </div>
          </div>

          {/* Step 2 */}
          <div className="flex gap-4 p-4 rounded-xl bg-slate-800/50 border border-slate-700/50">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-red-600 font-bold text-white shrink-0">
              2
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-white flex items-center gap-2">
                Copy Stream URL & Stream Key
                <Key className="w-4 h-4 text-amber-400" />
              </h4>
              <p className="text-slate-300">
                In the <strong className="text-white">Stream Settings</strong> tab on YouTube Studio:
              </p>
              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono space-y-1">
                  <div className="text-slate-400">Stream URL (Default):</div>
                  <div className="text-emerald-400 font-semibold selection:bg-emerald-900">
                    rtmp://a.rtmp.youtube.com/live2
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono space-y-1">
                  <div className="text-slate-400">Stream Key (Keep secret!):</div>
                  <div className="text-amber-400 font-semibold">
                    xxxx-xxxx-xxxx-xxxx-xxxx
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Step 3 */}
          <div className="flex gap-4 p-4 rounded-xl bg-slate-800/50 border border-slate-700/50">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-red-600 font-bold text-white shrink-0">
              3
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-white flex items-center gap-2">
                Paste Credentials & Start Streaming
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </h4>
              <p className="text-slate-300">
                Paste the Stream Key into the app, pick your local MP4 video file, ensure{' '}
                <strong className="text-emerald-400">Loop video</strong> is checked for continuous playback, and click{' '}
                <strong className="text-emerald-400">START STREAM</strong>.
              </p>
            </div>
          </div>

          {/* Pro Tips */}
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs space-y-2">
            <div className="font-semibold flex items-center gap-2 text-amber-400">
              <ShieldCheck className="w-4 h-4" /> YouTube Live Recommended Video Settings:
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-300">
              <li>Video Codec: H.264 (AAC Audio) inside MP4 wrapper</li>
              <li>Recommended Bitrate: 4,500 - 6,000 kbps for 1080p @ 60fps</li>
              <li>Keyframe Interval: 2 seconds (-g 60 for 30fps video)</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-4 border-t border-slate-800 bg-slate-900/80">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-medium text-xs transition-colors"
          >
            Got it, take me back
          </button>
        </div>
      </div>
    </div>
  );
};
