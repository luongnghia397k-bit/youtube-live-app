import React, { useState } from 'react';
import { Copy, Check, Terminal, Cpu, Repeat, Zap, ShieldAlert, Sparkles } from 'lucide-react';
import { StreamConfig } from '../types';

interface FFmpegCommandBuilderProps {
  config: StreamConfig;
}

export const FFmpegCommandBuilder: React.FC<FFmpegCommandBuilderProps> = ({ config }) => {
  const [copied, setCopied] = useState(false);

  const fullRtmp = config.streamKey
    ? `${config.rtmpUrl.replace(/\/$/, '')}/${config.streamKey}`
    : `${config.rtmpUrl.replace(/\/$/, '')}/YOUR_STREAM_KEY`;

  const videoInputPath = config.uploadedFileName
    ? `/sdcard/Download/${config.uploadedFileName}`
    : `/sdcard/Movies/sample_video.mp4`;

  // Build FFmpeg command args
  const loopFlag = config.loopVideo ? '-stream_loop -1' : '';
  const codecFlag =
    config.qualityPreset === 'passthrough'
      ? '-c:v copy -c:a aac'
      : config.qualityPreset === '1080p60'
      ? '-c:v libx264 -preset ultrafast -tune zerolatency -b:v 4500k -maxrate 4500k -bufsize 9000k -pix_fmt yuv420p -g 60 -c:a aac -b:a 128k -ar 44100'
      : '-c:v libx264 -preset ultrafast -tune zerolatency -b:v 2500k -maxrate 2500k -bufsize 5000k -pix_fmt yuv420p -g 60 -c:a aac -b:a 128k -ar 44100';

  const fullCommand = `ffmpeg -re ${loopFlag} -i "${videoInputPath}" ${codecFlag} -f flv "${fullRtmp}"`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              FFmpeg Android Command Generator
              <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                FFmpegKit v6.0
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Live preview of the FFmpeg command executed by the Android background service
            </p>
          </div>
        </div>

        <button
          onClick={handleCopy}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-all shadow-lg shadow-purple-600/20 shrink-0"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
          {copied ? 'Copied Command!' : 'Copy Command'}
        </button>
      </div>

      {/* Code Display Box */}
      <div className="relative group rounded-xl bg-slate-950 border border-slate-800 p-4 font-mono text-xs text-emerald-400 overflow-x-auto selection:bg-purple-900 selection:text-purple-100">
        <div className="text-slate-500 select-none pb-2 text-[10px]"># Native Android Terminal Execution string</div>
        <code>{fullCommand}</code>
      </div>

      {/* Flag Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
        <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/40 space-y-1">
          <div className="font-semibold text-purple-300 flex items-center gap-1.5 font-mono">
            <Zap className="w-3.5 h-3.5 text-amber-400" /> -re (Real-time speed)
          </div>
          <p className="text-slate-400">Reads input video at native framerate (prevents uploading 10x faster than real-time).</p>
        </div>

        <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/40 space-y-1">
          <div className="font-semibold text-purple-300 flex items-center gap-1.5 font-mono">
            <Repeat className="w-3.5 h-3.5 text-emerald-400" /> -stream_loop -1
          </div>
          <p className="text-slate-400">
            {config.loopVideo
              ? 'Loop video infinitely without dropping connection to YouTube Live.'
              : 'Disabled: Stream stops automatically after video completes once.'}
          </p>
        </div>

        <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/40 space-y-1">
          <div className="font-semibold text-purple-300 flex items-center gap-1.5 font-mono">
            <Cpu className="w-3.5 h-3.5 text-blue-400" /> -c:v {config.qualityPreset === 'passthrough' ? 'copy' : 'libx264'}
          </div>
          <p className="text-slate-400">
            {config.qualityPreset === 'passthrough'
              ? 'Passthrough Copy Mode: Zero CPU overhead, streams original H.264 video bytes directly.'
              : 'Real-time H.264 encoder tuned for zerolatency streaming.'}
          </p>
        </div>
      </div>
    </div>
  );
};
