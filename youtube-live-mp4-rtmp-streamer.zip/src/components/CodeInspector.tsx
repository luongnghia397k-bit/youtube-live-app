import React, { useState } from 'react';
import { FileCode, Copy, Check, Download, FolderArchive, Sparkles, Code2, Smartphone } from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_CODEBASE } from '../data/androidCodebase';
import { AndroidCodeFile } from '../types';

export const CodeInspector: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidCodeFile>(ANDROID_CODEBASE[0]);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Add files to zip
      ANDROID_CODEBASE.forEach((file) => {
        zip.file(file.path, file.content);
      });

      // Add top-level settings.gradle.kts
      zip.file(
        'settings.gradle.kts',
        `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "YTLiveStreamer"
include(":app")
`
      );

      // Generate blob
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'YTLiveStreamer_Android_Kotlin_Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create zip', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-2xl flex flex-col h-[750px]">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 sm:px-6 bg-slate-950 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              Android Kotlin Source Code
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Android Studio Project
              </span>
            </h3>
            <p className="text-xs text-slate-400">Jetpack Compose UI, Foreground Service & FFmpegKit integration</p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={handleCopy}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied File!' : 'Copy File'}
          </button>

          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-lg shadow-emerald-600/20"
          >
            <FolderArchive className="w-4 h-4" />
            {isZipping ? 'Zipping Project...' : 'Download Project (.zip)'}
          </button>
        </div>
      </div>

      {/* Main Split Body */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Sidebar File Tree */}
        <div className="w-full md:w-72 bg-slate-950/60 border-r border-slate-800 p-3 space-y-2 overflow-y-auto shrink-0">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3 py-1">
            Project Files
          </div>
          <div className="space-y-1">
            {ANDROID_CODEBASE.map((file) => {
              const isSelected = selectedFile.id === file.id;
              return (
                <button
                  key={file.id}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-medium text-left transition-all ${
                    isSelected
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <div className="truncate">
                    <div className="truncate font-mono">{file.filename}</div>
                    <div className="text-[10px] text-slate-500 truncate">{file.category}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Content View */}
        <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
          {/* File Path Banner */}
          <div className="px-6 py-2.5 bg-slate-900/40 border-b border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span className="truncate">{selectedFile.path}</span>
            <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
              {selectedFile.language}
            </span>
          </div>

          <p className="px-6 py-2 text-xs text-slate-400 border-b border-slate-800/40 bg-slate-900/20">
            💡 {selectedFile.description}
          </p>

          {/* Source Code Container */}
          <div className="flex-1 p-6 overflow-auto font-mono text-xs leading-relaxed text-slate-200 selection:bg-emerald-900">
            <pre>
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
