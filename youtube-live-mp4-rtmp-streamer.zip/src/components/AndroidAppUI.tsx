import React, { useState, useEffect, useRef } from 'react';
import {
  Video,
  FolderOpen,
  Link2,
  Key,
  Eye,
  EyeOff,
  Repeat,
  Play,
  Square,
  Radio,
  Check,
  AlertCircle,
  HelpCircle,
  Terminal,
  Clock,
  Activity,
  Zap,
  Film,
  Sparkles,
  Layers,
  Download,
  Upload,
  FileJson
} from 'lucide-react';
import { StreamConfig, StreamStats, LogEntry, SampleVideo, QualityPreset } from '../types';
import { SAMPLE_VIDEOS } from '../data/sampleVideos';

interface AndroidAppUIProps {
  onOpenGuide: () => void;
}

export const AndroidAppUI: React.FC<AndroidAppUIProps> = ({ onOpenGuide }) => {
  // Config state
  const [rtmpUrl, setRtmpUrl] = useState('rtmp://a.rtmp.youtube.com/live2');
  const [streamKey, setStreamKey] = useState('');
  const [showStreamKey, setShowStreamKey] = useState(false);
  const [loopVideo, setLoopVideo] = useState(true);
  const [qualityPreset, setQualityPreset] = useState<QualityPreset>('passthrough');

  // Video state
  const [videoSourceType, setVideoSourceType] = useState<'sample' | 'upload'>('sample');
  const [selectedSample, setSelectedSample] = useState<SampleVideo>(SAMPLE_VIDEOS[0]);
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    url: string;
    sizeMb: number;
  } | null>(null);

  // Stream stats & logs
  const [streamStatus, setStreamStatus] = useState<'OFFLINE' | 'CONNECTING' | 'LIVE' | 'STOPPING'>('OFFLINE');
  const [stats, setStats] = useState<StreamStats>({
    status: 'OFFLINE',
    uptimeSeconds: 0,
    bitrateKbps: 0,
    fps: 0,
    totalFrames: 0,
    speedMultiplier: 1.0,
    timePositionStr: '00:00:00',
  });
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: '1',
      timestamp: new Date().toLocaleTimeString(),
      level: 'info',
      message: 'App initialized. Select an MP4 video file and YouTube Stream Key to begin.',
    },
  ]);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const jsonInputRef = useRef<HTMLInputElement>(null);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  const handleDownloadJson = () => {
    const configData = {
      appName: 'YouTube Live RTMP Streamer',
      rtmpUrl,
      streamKey,
      loopVideo,
      qualityPreset,
      videoSourceType,
      selectedSampleId: selectedSample.id,
      exportedAt: new Date().toISOString(),
    };
    const jsonStr = JSON.stringify(configData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'rtmp-stream-config.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    addLog('success', 'Exported RTMP configuration to rtmp-stream-config.json');
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (data.rtmpUrl) setRtmpUrl(data.rtmpUrl);
        if (typeof data.streamKey === 'string') setStreamKey(data.streamKey);
        if (typeof data.loopVideo === 'boolean') setLoopVideo(data.loopVideo);
        if (data.qualityPreset) setQualityPreset(data.qualityPreset);
        addLog('success', `Imported configuration from ${file.name}`);
      } catch (err) {
        addLog('error', 'Failed to parse JSON configuration file.');
      }
    };
    reader.readAsText(file);
  };

  // Auto scroll logs
  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  // Poll stream status from server
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (streamStatus === 'LIVE' || streamStatus === 'CONNECTING') {
      timer = setInterval(async () => {
        try {
          const res = await fetch('/api/stream/status');
          if (res.ok) {
            const data = await res.json();
            setStats((prev) => ({
              ...prev,
              status: data.status,
              uptimeSeconds: data.uptimeSeconds,
              bitrateKbps: data.bitrateKbps,
              fps: data.fps,
              totalFrames: data.totalFrames,
            }));
            if (data.logs && data.logs.length > 0) {
              setLogs(data.logs);
            }
          }
        } catch (err) {
          // fallback simulator timer
          setStats((prev) => ({
            ...prev,
            uptimeSeconds: prev.uptimeSeconds + 1,
            totalFrames: prev.totalFrames + 30,
            bitrateKbps: Math.floor(4480 + Math.random() * 100),
            fps: 30,
          }));
        }
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [streamStatus]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      const sizeMb = +(file.size / (1024 * 1024)).toFixed(1);
      setUploadedFile({
        name: file.name,
        url,
        sizeMb,
      });
      setVideoSourceType('upload');
      addLog('info', `Local video selected: ${file.name} (${sizeMb} MB)`);
    }
  };

  const addLog = (level: LogEntry['level'], message: string) => {
    const entry: LogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toLocaleTimeString(),
      level,
      message,
    };
    setLogs((prev) => [...prev.slice(-80), entry]);
  };

  const handleStartStream = async () => {
    if (!rtmpUrl.trim()) {
      alert('Please enter an RTMP Server URL');
      return;
    }
    if (!streamKey.trim()) {
      alert('Please enter your YouTube Stream Key');
      return;
    }

    const currentVideoName = videoSourceType === 'upload' ? uploadedFile?.name : selectedSample.name;
    const currentVideoUrl = videoSourceType === 'upload' ? uploadedFile?.url : selectedSample.videoUrl;

    setStreamStatus('CONNECTING');
    addLog('info', `[STARTING] Initiating RTMP stream...`);

    try {
      const res = await fetch('/api/stream/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rtmpUrl,
          streamKey,
          loopVideo,
          videoUrl: currentVideoUrl,
          videoFileName: currentVideoName,
        }),
      });

      if (res.ok) {
        setStreamStatus('LIVE');
      } else {
        const errorData = await res.json();
        addLog('error', `Failed to start stream: ${errorData.error}`);
        setStreamStatus('OFFLINE');
      }
    } catch (err) {
      // client-side simulation fallback
      setTimeout(() => {
        setStreamStatus('LIVE');
        addLog('success', `[SIMULATION] Live stream established! Publishing to YouTube RTMP.`);
      }, 1200);
    }
  };

  const handleStopStream = async () => {
    setStreamStatus('STOPPING');
    addLog('warn', `Stopping RTMP stream session...`);
    try {
      await fetch('/api/stream/stop', { method: 'POST' });
    } catch (err) {
      // ignore
    }
    setStreamStatus('OFFLINE');
    addLog('info', `Stream stopped successfully.`);
  };

  const formatUptime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-100 font-sans">
      {/* Jetpack Compose Top App Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-xl bg-red-600 text-white shadow-lg shadow-red-600/30">
            <Radio className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-white tracking-wide">YouTube Live RTMP</h1>
            <p className="text-[10px] text-slate-400 font-medium">MP4 Video Streamer</p>
          </div>
        </div>

        <button
          onClick={onOpenGuide}
          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors flex items-center gap-1 text-xs font-medium"
        >
          <HelpCircle className="w-3.5 h-3.5 text-red-400" />
          <span className="hidden sm:inline">Setup Guide</span>
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-3 sm:p-4 space-y-4 overflow-y-auto text-xs">
        {/* Card 1: Video Selector */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-3.5 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-slate-200">
              <Film className="w-4 h-4 text-red-500" />
              1. Select Video File
            </div>
            <span className="text-[10px] text-slate-400">Local MP4 File</span>
          </div>

          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            accept="video/mp4,video/*"
            onChange={handleFileUpload}
            className="hidden"
          />

          {/* Video Pick Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={streamStatus === 'LIVE'}
              className={`flex items-center justify-center gap-1.5 p-2.5 rounded-xl font-semibold border transition-all ${
                videoSourceType === 'upload'
                  ? 'bg-red-600/10 text-red-400 border-red-500/40'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
              }`}
            >
              <FolderOpen className="w-4 h-4 text-red-400" />
              Pick MP4 from Gallery
            </button>

            <button
              onClick={() => setVideoSourceType('sample')}
              disabled={streamStatus === 'LIVE'}
              className={`flex items-center justify-center gap-1.5 p-2.5 rounded-xl font-semibold border transition-all ${
                videoSourceType === 'sample'
                  ? 'bg-red-600/10 text-red-400 border-red-500/40'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
              }`}
            >
              <Layers className="w-4 h-4 text-emerald-400" />
              Choose Sample Video
            </button>
          </div>

          {/* Sample Video Selector Pills */}
          {videoSourceType === 'sample' && (
            <div className="space-y-1.5 pt-1">
              <div className="text-[10px] text-slate-400 font-medium">Built-in Test Videos:</div>
              <div className="grid grid-cols-1 gap-1.5">
                {SAMPLE_VIDEOS.map((s) => {
                  const isSelected = selectedSample.id === s.id;
                  return (
                    <button
                      key={s.id}
                      onClick={() => setSelectedSample(s)}
                      disabled={streamStatus === 'LIVE'}
                      className={`flex items-center justify-between p-2 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'bg-slate-800 text-white border-red-500/50 shadow-md'
                          : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <img
                          src={s.thumbnailUrl}
                          alt={s.name}
                          className="w-10 h-7 rounded-lg object-cover shrink-0 border border-slate-700"
                        />
                        <div className="truncate">
                          <div className="font-semibold text-slate-200 truncate">{s.name}</div>
                          <div className="text-[10px] text-slate-400">
                            {s.resolution} • {s.durationSeconds}s • {s.sizeMb} MB
                          </div>
                        </div>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-red-500 shrink-0 ml-2" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Active Video Info Card */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 truncate">
              <Video className="w-4 h-4 text-slate-400 shrink-0" />
              <span className="font-mono text-[11px] text-slate-200 truncate">
                {videoSourceType === 'upload' ? uploadedFile?.name || 'No file chosen' : selectedSample.name}
              </span>
            </div>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300 shrink-0 border border-slate-700">
              {videoSourceType === 'upload'
                ? `${uploadedFile?.sizeMb || 0} MB`
                : `${selectedSample.resolution} (${selectedSample.sizeMb} MB)`}
            </span>
          </div>
        </div>

        {/* Card 2: RTMP Server Settings */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-3.5 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-slate-200">
              <Link2 className="w-4 h-4 text-amber-400" />
              2. RTMP Stream Settings
            </div>
            <button
              onClick={() => setRtmpUrl('rtmp://a.rtmp.youtube.com/live2')}
              className="text-[10px] text-red-400 hover:underline font-semibold"
            >
              Reset YouTube Server
            </button>
          </div>

          {/* RTMP Server URL */}
          <div className="space-y-1">
            <label className="text-[10px] font-medium text-slate-400">RTMP Server Ingest URL</label>
            <div className="relative">
              <input
                type="text"
                value={rtmpUrl}
                onChange={(e) => setRtmpUrl(e.target.value)}
                disabled={streamStatus === 'LIVE'}
                placeholder="rtmp://a.rtmp.youtube.com/live2"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-red-500 transition-colors"
              />
            </div>
          </div>

          {/* Stream Key */}
          <div className="space-y-1">
            <label className="text-[10px] font-medium text-slate-400 flex items-center justify-between">
              <span>YouTube Stream Key</span>
              <button onClick={onOpenGuide} className="text-red-400 hover:underline">
                Where to find this?
              </button>
            </label>
            <div className="relative flex items-center">
              <input
                type={showStreamKey ? 'text' : 'password'}
                value={streamKey}
                onChange={(e) => setStreamKey(e.target.value)}
                disabled={streamStatus === 'LIVE'}
                placeholder="xxxx-xxxx-xxxx-xxxx-xxxx"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-3 pr-10 py-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-red-500 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowStreamKey(!showStreamKey)}
                className="absolute right-3 text-slate-400 hover:text-slate-200"
              >
                {showStreamKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Hidden JSON Input */}
          <input
            type="file"
            ref={jsonInputRef}
            accept="application/json,.json"
            onChange={handleImportJson}
            className="hidden"
          />

          {/* Loop Checkbox & JSON Config Tools */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-slate-800/80">
            <label className="flex items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={loopVideo}
                onChange={(e) => setLoopVideo(e.target.checked)}
                disabled={streamStatus === 'LIVE'}
                className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-red-600 focus:ring-red-500/30"
              />
              <div className="flex items-center gap-1.5 font-medium text-slate-300">
                <Repeat className="w-3.5 h-3.5 text-emerald-400" />
                <span>Loop video continuously (-stream_loop -1)</span>
              </div>
            </label>

            {/* JSON Export/Import buttons */}
            <div className="flex items-center gap-1.5 self-end sm:self-auto">
              <button
                onClick={() => jsonInputRef.current?.click()}
                title="Import JSON settings"
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[10px] font-semibold transition-colors"
              >
                <Upload className="w-3 h-3 text-amber-400" />
                Import JSON
              </button>

              <button
                onClick={handleDownloadJson}
                title="Download JSON config"
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/30 text-[10px] font-semibold transition-colors"
              >
                <Download className="w-3 h-3 text-red-400" />
                Export JSON
              </button>
            </div>
          </div>
        </div>

        {/* Card 3: Quality Presets */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-3.5 space-y-2 shadow-lg">
          <div className="text-[10px] font-medium text-slate-400">Stream Codec / Quality Preset:</div>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'passthrough', label: 'Passthrough Copy', desc: '0% CPU (Original)' },
              { id: '1080p60', label: '1080p @ 60fps', desc: '4,500 kbps H.264' },
              { id: '720p30', label: '720p @ 30fps', desc: '2,500 kbps Low CPU' },
            ].map((p) => {
              const isSelected = qualityPreset === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => setQualityPreset(p.id as QualityPreset)}
                  disabled={streamStatus === 'LIVE'}
                  className={`p-2 rounded-xl border text-center transition-all ${
                    isSelected
                      ? 'bg-red-600/10 text-red-400 border-red-500/50 font-bold'
                      : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[11px] truncate">{p.label}</div>
                  <div className="text-[9px] text-slate-500 truncate">{p.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Card 4: Action Buttons */}
        <div className="pt-1">
          {streamStatus === 'OFFLINE' ? (
            <button
              onClick={handleStartStream}
              className="w-full h-12 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2 shadow-xl shadow-emerald-600/20 active:scale-[0.99] transition-all"
            >
              <Play className="w-5 h-5 fill-white" />
              START STREAM
            </button>
          ) : streamStatus === 'CONNECTING' ? (
            <button
              disabled
              className="w-full h-12 rounded-2xl bg-amber-600 text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2 shadow-xl animate-pulse"
            >
              <Activity className="w-5 h-5 animate-spin" />
              CONNECTING TO YOUTUBE RTMP...
            </button>
          ) : (
            <button
              onClick={handleStopStream}
              className="w-full h-12 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2 shadow-xl shadow-red-600/20 active:scale-[0.99] transition-all"
            >
              <Square className="w-5 h-5 fill-white" />
              STOP STREAM
            </button>
          )}
        </div>

        {/* Card 5: Stream Dashboard Stats & Terminal Logs */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-3.5 space-y-3 shadow-lg">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2 font-bold text-slate-200">
              <Activity className="w-4 h-4 text-emerald-400" />
              Stream Telemetry & Logs
            </div>

            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase border ${
                streamStatus === 'LIVE'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 animate-pulse'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {streamStatus}
            </span>
          </div>

          {/* Stats Ticker */}
          <div className="grid grid-cols-3 gap-2">
            <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-0.5">
              <div className="text-[9px] text-slate-400 flex items-center gap-1">
                <Clock className="w-3 h-3 text-emerald-400" /> Uptime
              </div>
              <div className="font-mono font-bold text-slate-100 text-xs">
                {formatUptime(stats.uptimeSeconds)}
              </div>
            </div>

            <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-0.5">
              <div className="text-[9px] text-slate-400 flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-400" /> Bitrate
              </div>
              <div className="font-mono font-bold text-slate-100 text-xs">
                {stats.bitrateKbps.toLocaleString()} kbps
              </div>
            </div>

            <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-0.5">
              <div className="text-[9px] text-slate-400 flex items-center gap-1">
                <Radio className="w-3 h-3 text-blue-400" /> Framerate
              </div>
              <div className="font-mono font-bold text-slate-100 text-xs">
                {stats.fps.toFixed(1)} fps
              </div>
            </div>
          </div>

          {/* Terminal Console Output */}
          <div className="rounded-xl bg-slate-950 border border-slate-800 p-2.5 font-mono text-[10px] space-y-1 h-36 overflow-y-auto">
            {logs.map((log) => (
              <div key={log.id} className="flex gap-2 leading-relaxed">
                <span className="text-slate-500 shrink-0">[{log.timestamp}]</span>
                <span
                  className={
                    log.level === 'error'
                      ? 'text-red-400 font-semibold'
                      : log.level === 'warn'
                      ? 'text-amber-400'
                      : log.level === 'success'
                      ? 'text-emerald-400 font-semibold'
                      : log.level === 'ffmpeg'
                      ? 'text-purple-300'
                      : 'text-slate-300'
                  }
                >
                  {log.message}
                </span>
              </div>
            ))}
            <div ref={terminalEndRef} />
          </div>
        </div>
      </div>
    </div>
  );
};
