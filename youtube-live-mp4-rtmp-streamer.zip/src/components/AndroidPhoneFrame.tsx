import React, { useState, useEffect } from 'react';
import { Wifi, Battery, Signal, Maximize2, Minimize2, Sparkles, Smartphone } from 'lucide-react';

interface AndroidPhoneFrameProps {
  children: React.ReactNode;
}

export const AndroidPhoneFrame: React.FC<AndroidPhoneFrameProps> = ({ children }) => {
  const [currentTime, setCurrentTime] = useState('10:45');
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateClock();
    const timer = setInterval(updateClock, 30000);
    return () => clearInterval(timer);
  }, []);

  if (isExpanded) {
    return (
      <div className="w-full rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-4 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-xs text-slate-400 font-semibold uppercase tracking-wide">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            Expanded Screen Mode
          </div>
          <button
            onClick={() => setIsExpanded(false)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
          >
            <Minimize2 className="w-3.5 h-3.5" />
            Switch to Phone Mockup Frame
          </button>
        </div>
        <div className="max-w-4xl mx-auto">{children}</div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center">
      {/* Frame Toggle Header */}
      <div className="mb-3 flex items-center justify-between w-full max-w-[410px] px-2 text-xs text-slate-400">
        <span className="flex items-center gap-1.5 font-medium">
          <Smartphone className="w-4 h-4 text-emerald-400" /> Android 14 Smartphone
        </span>
        <button
          onClick={() => setIsExpanded(true)}
          className="inline-flex items-center gap-1 text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 px-2.5 py-1 rounded-lg transition-colors font-medium text-[11px]"
        >
          <Maximize2 className="w-3 h-3" /> Expand Layout
        </button>
      </div>

      {/* Phone Hardware Shell */}
      <div className="relative w-full max-w-[410px] min-h-[780px] bg-slate-950 rounded-[48px] p-3 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] border-4 border-slate-800 ring-1 ring-slate-700/50">
        {/* Side Hardware Buttons */}
        <div className="absolute -left-[7px] top-28 w-[3px] h-10 bg-slate-700 rounded-l-md" />
        <div className="absolute -left-[7px] top-42 w-[3px] h-14 bg-slate-700 rounded-l-md" />
        <div className="absolute -left-[7px] top-60 w-[3px] h-14 bg-slate-700 rounded-l-md" />
        <div className="absolute -right-[7px] top-36 w-[3px] h-16 bg-slate-700 rounded-r-md" />

        {/* Screen Display Container */}
        <div className="relative w-full min-h-[756px] bg-slate-900 rounded-[38px] overflow-hidden flex flex-col border border-slate-800">
          {/* Android Status Bar */}
          <div className="h-9 px-6 bg-slate-950/90 text-slate-300 flex items-center justify-between text-xs font-semibold select-none z-20 shrink-0 border-b border-slate-800/40">
            <span>{currentTime}</span>

            {/* Top Hole Punch Camera Notch */}
            <div className="absolute left-1/2 -translate-x-1/2 top-2.5 w-4 h-4 rounded-full bg-black ring-2 ring-slate-800/60" />

            <div className="flex items-center gap-2 text-slate-400">
              <Signal className="w-3.5 h-3.5 text-slate-200" />
              <Wifi className="w-3.5 h-3.5 text-slate-200" />
              <div className="flex items-center gap-1">
                <span className="text-[10px] font-bold">98%</span>
                <Battery className="w-4 h-4 text-emerald-400 fill-emerald-400" />
              </div>
            </div>
          </div>

          {/* App Display Viewport */}
          <div className="flex-1 overflow-y-auto bg-slate-900 text-slate-100 flex flex-col">
            {children}
          </div>

          {/* Bottom Android Gesture Navigation Bar */}
          <div className="h-6 bg-slate-950 flex items-center justify-center shrink-0 z-20">
            <div className="w-32 h-1 bg-slate-500/60 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
