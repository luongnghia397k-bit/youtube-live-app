import { SampleVideo } from '../types';

export const SAMPLE_VIDEOS: SampleVideo[] = [
  {
    id: 'nature_loop',
    name: '4K Tropical Nature Loop',
    description: 'Vibrant looping ocean waves & palm trees scene for smooth YouTube Live test streaming.',
    durationSeconds: 30,
    resolution: '1920x1080',
    sizeMb: 12.4,
    thumbnailUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
  },
  {
    id: 'tech_countdown',
    name: 'Cyberpunk Tech Stream Countdown',
    description: 'Animated 1080p neon countdown timer video ideal for testing YouTube Live start screens.',
    durationSeconds: 60,
    resolution: '1920x1080',
    sizeMb: 18.2,
    thumbnailUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4'
  },
  {
    id: 'lofi_ambient',
    name: 'Lofi Chill City Loop',
    description: 'Cinematic rainy city street loop perfect for 24/7 continuous stream loop testing.',
    durationSeconds: 45,
    resolution: '1920x1080',
    sizeMb: 15.8,
    thumbnailUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?auto=format&fit=crop&w=800&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
  }
];
