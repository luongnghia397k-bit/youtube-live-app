import { AndroidCodeFile } from '../types';

export const ANDROID_CODEBASE: AndroidCodeFile[] = [
  {
    id: 'rtmp_config_model',
    path: 'app/src/main/java/com/ytlive/rtmpstreamer/RtmpConfig.kt',
    filename: 'RtmpConfig.kt',
    language: 'kotlin',
    category: 'ui',
    description: 'Kotlin data model and JSON parser helper for exporting and importing RTMP settings.',
    content: `package com.ytlive.rtmpstreamer

import org.json.JSONObject

data class RtmpConfig(
    val rtmpUrl: String = "rtmp://a.rtmp.youtube.com/live2",
    val streamKey: String = "",
    val loopVideo: Boolean = true,
    val qualityPreset: String = "passthrough"
) {
    fun toJsonString(): String {
        val json = JSONObject()
        json.put("appName", "YouTube Live RTMP Streamer")
        json.put("rtmpUrl", rtmpUrl)
        json.put("streamKey", streamKey)
        json.put("loopVideo", loopVideo)
        json.put("qualityPreset", qualityPreset)
        return json.toString(2)
    }

    companion object {
        fun parseJson(jsonStr: String): RtmpConfig {
            val json = JSONObject(jsonStr)
            return RtmpConfig(
                rtmpUrl = json.optString("rtmpUrl", "rtmp://a.rtmp.youtube.com/live2"),
                streamKey = json.optString("streamKey", ""),
                loopVideo = json.optBoolean("loopVideo", true),
                qualityPreset = json.optString("qualityPreset", "passthrough")
            )
        }
    }
}
`
  },
  {
    id: 'main_activity',
    path: 'app/src/main/java/com/ytlive/rtmpstreamer/MainActivity.kt',
    filename: 'MainActivity.kt',
    language: 'kotlin',
    category: 'ui',
    description: 'Jetpack Compose UI activity with Video Picker, RTMP inputs, Loop toggle, and Service controls.',
    content: `package com.ytlive.rtmpstreamer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ytlive.rtmpstreamer.ui.theme.YTLiveTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            YTLiveTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RtmpStreamerScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RtmpStreamerScreen() {
    val context = LocalContext.current
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedVideoName by remember { mutableStateOf("No video selected") }
    
    var rtmpUrl by remember { mutableStateOf("rtmp://a.rtmp.youtube.com/live2") }
    var streamKey by remember { mutableStateOf("") }
    var showStreamKey by remember { mutableStateOf(false) }
    var loopVideo by remember { mutableStateOf(true) }
    
    var isStreaming by remember { mutableStateOf(false) }

    // Gallery Picker launcher
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            selectedVideoUri = it
            selectedVideoName = it.lastPathSegment ?: "Selected Video.mp4"
            Toast.makeText(context, "Video selected!", Toast.LENGTH_SHORT).show()
        }
    }

    // Permission launcher for Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.entries.all { it.value }
        if (!granted) {
            Toast.makeText(context, "Storage/Notification permission required!", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("YouTube Live RTMP Streamer", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Video Selection Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.VideoFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("1. Select Video File", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = selectedVideoName,
                        fontSize = 14.sp,
                        color = if (selectedVideoUri != null) MaterialTheme.colorScheme.primary else Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { videoPickerLauncher.launch("video/mp4") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isStreaming
                    ) {
                        Icon(Icons.Default.Folder, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (selectedVideoUri == null) "Pick Video from Gallery" else "Change Video")
                    }
                }
            }

            // 2. Stream Configuration Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.RssFeed, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("2. RTMP Stream Settings", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // RTMP Server URL Input
                    OutlinedTextField(
                        value = rtmpUrl,
                        onValueChange = { rtmpUrl = it },
                        label = { Text("RTMP Server URL") },
                        placeholder = { Text("rtmp://a.rtmp.youtube.com/live2") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        enabled = !isStreaming,
                        leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) }
                    )

                    // Stream Key Input
                    OutlinedTextField(
                        value = streamKey,
                        onValueChange = { streamKey = it },
                        label = { Text("YouTube Stream Key") },
                        placeholder = { Text("xxxx-xxxx-xxxx-xxxx-xxxx") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        enabled = !isStreaming,
                        visualTransformation = if (showStreamKey) VisualTransformation.None else PasswordVisualTransformation(),
                        leadingIcon = { Icon(Icons.Default.VpnKey, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { showStreamKey = !showStreamKey }) {
                                Icon(
                                    if (showStreamKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle Key Visibility"
                                )
                            }
                        }
                    )

                    // Loop Checkbox
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Checkbox(
                            checked = loopVideo,
                            onCheckedChange = { loopVideo = it },
                            enabled = !isStreaming
                        )
                        Text("Loop video continuously (-stream_loop -1)", fontSize = 15.sp)
                    }
                }
            }

            // 3. Action Buttons (Start / Stop)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isStreaming) {
                    Button(
                        onClick = {
                            if (selectedVideoUri == null) {
                                Toast.makeText(context, "Please select an MP4 video first!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (streamKey.isBlank()) {
                                Toast.makeText(context, "Please enter your YouTube Stream Key!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            // Start Foreground Service
                            val intent = Intent(context, RtmpStreamService::class.java).apply {
                                action = RtmpStreamService.ACTION_START
                                putExtra(RtmpStreamService.EXTRA_VIDEO_URI, selectedVideoUri.toString())
                                putExtra(RtmpStreamService.EXTRA_RTMP_URL, rtmpUrl)
                                putExtra(RtmpStreamService.EXTRA_STREAM_KEY, streamKey)
                                putExtra(RtmpStreamService.EXTRA_LOOP, loopVideo)
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                context.startForegroundService(intent)
                            } else {
                                context.startService(intent)
                            }
                            isStreaming = true
                            Toast.makeText(context, "Starting Live Stream...", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("START STREAM", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = {
                            val intent = Intent(context, RtmpStreamService::class.java).apply {
                                action = RtmpStreamService.ACTION_STOP
                            }
                            context.startService(intent)
                            isStreaming = false
                            Toast.makeText(context, "Stopping Stream...", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("STOP STREAM", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Stream Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (isStreaming) Color(0xFF064E3B) else MaterialTheme.colorScheme.surface
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isStreaming) "LIVE BROADCAST ACTIVE" else "STREAM DISCONNECTED",
                        color = if (isStreaming) Color(0xFF34D399) else Color.Gray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isStreaming) "Streaming MP4 file to YouTube Live" else "Configure settings above and press START STREAM",
                        fontSize = 13.sp,
                        color = Color.LightGray
                    )
                }
            }
        }
    }
}
`
  },
  {
    id: 'rtmp_service',
    path: 'app/src/main/java/com/ytlive/rtmpstreamer/RtmpStreamService.kt',
    filename: 'RtmpStreamService.kt',
    language: 'kotlin',
    category: 'service',
    description: 'Android Foreground Service managing background FFmpegKit RTMP stream execution and notifications.',
    content: `package com.ytlive.rtmpstreamer

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode

class RtmpStreamService : Service() {

    private var ffmpegSession: FFmpegSession? = null

    companion object {
        const val TAG = "RtmpStreamService"
        const val CHANNEL_ID = "rtmp_stream_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "ACTION_START_STREAM"
        const val ACTION_STOP = "ACTION_STOP_STREAM"

        const val EXTRA_VIDEO_URI = "extra_video_uri"
        const val EXTRA_RTMP_URL = "extra_rtmp_url"
        const val EXTRA_STREAM_KEY = "extra_stream_key"
        const val EXTRA_LOOP = "extra_loop"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val videoUriStr = intent.getStringExtra(EXTRA_VIDEO_URI)
                val rtmpUrl = intent.getStringExtra(EXTRA_RTMP_URL) ?: "rtmp://a.rtmp.youtube.com/live2"
                val streamKey = intent.getStringExtra(EXTRA_STREAM_KEY) ?: ""
                val loop = intent.getBooleanExtra(EXTRA_LOOP, true)

                if (!videoUriStr.isNullOrEmpty() && streamKey.isNotEmpty()) {
                    val notification = buildNotification("YouTube Live Stream Active")
                    startForeground(NOTIFICATION_ID, notification)
                    startFfmpegStream(videoUriStr, rtmpUrl, streamKey, loop)
                }
            }
            ACTION_STOP -> {
                stopFfmpegStream()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startFfmpegStream(videoUriStr: String, rtmpUrl: String, streamKey: String, loop: Boolean) {
        val fullDestination = if (rtmpUrl.endsWith("/")) "$rtmpUrl$streamKey" else "$rtmpUrl/$streamKey"
        
        // Convert Content URI to file path or FFmpeg readable input
        val videoInput = Uri.parse(videoUriStr).path ?: videoUriStr

        // FFmpeg Command Construction
        // -re: Read input at native frame rate
        // -stream_loop -1: Infinite video loop
        // -c:v copy -c:a aac: Fast stream copy without re-encoding overhead
        val loopFlag = if (loop) "-stream_loop -1" else ""
        val ffmpegCmd = "-re $loopFlag -i \"$videoInput\" -c:v copy -c:a aac -f flv \"$fullDestination\""

        Log.d(TAG, "Executing FFmpeg: $ffmpegCmd")

        ffmpegSession = FFmpegKit.executeAsync(
            ffmpegCmd,
            { session ->
                val returnCode = session.returnCode
                if (ReturnCode.isSuccess(returnCode)) {
                    Log.i(TAG, "FFmpeg Stream Completed Successfully")
                } else {
                    Log.e(TAG, "FFmpeg Stream Stopped/Failed code: $returnCode")
                }
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            },
            { log ->
                Log.d(TAG, "FFmpeg Log: ${'${log.message}'}")
            },
            { statistics ->
                Log.d(TAG, "FFmpeg Stats - Frame: ${'${statistics.videoFrameNumber}'}, Bitrate: ${'${statistics.bitrate}'} kbps")
            }
        )
    }

    private fun stopFfmpegStream() {
        ffmpegSession?.let {
            FFmpegKit.cancel(it.sessionId)
            Log.i(TAG, "FFmpeg Stream session cancelled")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "YouTube Live RTMP Streaming Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notification when video is streaming live to YouTube RTMP"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val stopIntent = Intent(this, RtmpStreamService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("YouTube Live Streamer")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "STOP STREAM", stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
`
  },
  {
    id: 'android_manifest',
    path: 'app/src/main/AndroidManifest.xml',
    filename: 'AndroidManifest.xml',
    language: 'xml',
    category: 'manifest',
    description: 'Android Manifest declaring video storage permissions, internet access, and Foreground Service.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Network & Storage Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    
    <!-- Foreground Service Permissions -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="YT Live Streamer"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.YTLiveStreamer">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="YT Live Streamer"
            android:theme="@style/Theme.YTLiveStreamer">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Foreground Service for RTMP Streaming -->
        <service
            android:name=".RtmpStreamService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="mediaPlayback" />

    </application>

</manifest>
`
  },
  {
    id: 'build_gradle_app',
    path: 'app/build.gradle.kts',
    filename: 'build.gradle.kts (App)',
    language: 'groovy',
    category: 'gradle',
    description: 'App-level Gradle dependencies including FFmpegKit and Jetpack Compose libraries.',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.ytlive.rtmpstreamer"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ytlive.rtmpstreamer"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    // Jetpack Compose & Material 3
    implementation(platform(libs.androidx.compose.bom))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.0")

    // FFmpeg Kit for Android (RTMP Video Streaming)
    implementation("com.arthenica:ffmpeg-kit-full:6.0-2")

    // Android Core & Coroutines
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")
}
`
  },
  {
    id: 'readme_guide',
    path: 'README.md',
    filename: 'README.md',
    language: 'markdown',
    category: 'docs',
    description: 'Step-by-step setup guide for building the Android app and starting YouTube Live streams.',
    content: `# YouTube Live MP4 RTMP Streamer (Android Kotlin)

A native Android application built with **Kotlin**, **Jetpack Compose**, and **FFmpegKit** that allows users to pick an MP4 video file from gallery and stream it continuously to a YouTube Live RTMP URL.

## Features
1. **Gallery Video Picker**: Select any local MP4 video file from device storage.
2. **RTMP Server & Key Inputs**: Pre-filled YouTube Live server URL with toggleable password mask for Stream Key.
3. **Loop Video Toggle**: Continuously stream video on repeat (-stream_loop -1).
4. **Foreground Streaming Service**: Keeps stream running smoothly in background when app is minimized.
5. **Start / Stop Controls**: Clean Material 3 controls with live status indicators.

## YouTube Live RTMP Setup
1. Go to [YouTube Creator Studio](https://studio.youtube.com).
2. Click **Create** > **Go Live**.
3. Under **Stream Settings**, copy:
   - **Stream URL**: rtmp://a.rtmp.youtube.com/live2
   - **Stream Key**: xxxx-xxxx-xxxx-xxxx-xxxx
4. Open the Android App, paste the Stream Key, select your MP4 video, check **Loop video**, and press **START STREAM**!
`
  }
];
